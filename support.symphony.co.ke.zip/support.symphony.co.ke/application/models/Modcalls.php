<?php
/**
 *  
 */
class Modcalls extends CI_Model
{
	
	function __construct()
	{
		parent:: __construct();
	}

	public function callopening($callnumber,$calldate,$openby,$contractno,$todo)
{
$data=array(
				'call_no'=>$callnumber,
				'call_date'=>$calldate,
				'technician'=>$this->session->userdata('user_id'),
				'contract_no'=>$contractno,
				'to_do'=>$todo,
				'status'=>'Pending'
								);

 		$this->db->insert('calls',$data);
 		if($this->db->affected_rows()>0){
 			return true;
 		}else{
 			return false;
 		}
 			
	}


public function check_call($callnumber){
	$this->db->select("call_no");
		$this->db->from("calls");
		$this->db->where("call_no",$callnumber);
		$query=$this->db->get();
		return $query->result();
}

	public function getcontractcalls(){
		$staffno= $this->session->userdata('user_id');
		$this->db->select("calls.call_no as callno,calls.call_date as calldate,staff.staffname as technician,clients.clientname as clientname,calls.to_do as todo,
		calls.status as status, contracts.contract_no ");
		$this->db->from("calls");
		$this->db->join('staff','calls.technician=staff.staffno','left');
		$this->db->join('contracts','calls.contract_no=contracts.contract_no','left');
		$this->db->join('clients','contracts.client_no=clients.client_no','left');
		$this->db->where('calls.technician ='.$staffno);
		$query=$this->db->get(); 
		
		return $query->result();
	}


public function getcsrcalls(){
	$staffno= $this->session->userdata('user_id');
$this->db->select("calls.call_no as callno,calls.call_date as calldate,staff.staffname as technician,clients.clientname as clientname,calls.to_do as todo,
		calls.status as status, supply_requests.csrno ");
		$this->db->from("calls");
		$this->db->join('staff','calls.technician=staff.staffno','left');
		$this->db->join('supply_requests','calls.contract_no=supply_requests.csrno','left');
		$this->db->join('clients','supply_requests.clientno=clients.client_no','left');
		$this->db->where('calls.technician ='.$staffno);
		$query=$this->db->get(); 

		return $query->result();

}
	
	public function getclients(){
		
		$this->db->select("clientname,client_no");
		$this->db->from("clients");
		$this->db->order_by("clientname", "asc");
		$query=$this->db->get();
		return $query->result();
	}

	public function searchcall($keyword) {  
	    
        $this->db->order_by('call_no', 'DESC');
        $this->db->like("call_no", $keyword);
        return $this->db->get('calls')->result_array();
    }

    public function getcontractdescription($client_id){
    	
       	$this->db->where('client_id',$client_id);
       	$this->db->order_by('cont_descrip','ASC');
       $query = $this->db->get('contracts');

       $output='<option value="">Select Contract</option>';

       foreach ($query->result() as $row) {
       	$output .='<option value="'.$row->contract_no.'">'.$row->contdescrip.'</option>';
       }
        
return $output;
  }



public function fetch_contdescription($client_id, $reference){

$output= '';

	if($reference =='CONTRACT'){
     $this->db->select('cont_descrip');
	$this->db->where('client_no',$client_id);
	$query=$this->db->get('contracts');
   $output= '<option value="">--Select Contract--</option>';
    foreach($query->result() as $row){
      $output .='<option value="'.$row->cont_descrip.'">'.$row->cont_descrip.'</option>';
	 }

	}
	else if($reference =='CSR'){
		 $this->db->select('description');
	$this->db->where('clientno',$client_id);
	$query=$this->db->get('supply_requests');
   $output= '<option value="">--Select CSR--</option>';
    foreach($query->result() as $row){
      $output .='<option value="'.$row->description.'">'.$row->description.'</option>';
	 }
	}
	
return $output;
}


public function fetch_contractnum($clientnum,$cont_description){
$contractnum='';

$this->db->select('contract_no');
$this->db->where('cont_descrip',$cont_description);
$this->db->where('client_no',$clientnum);
$query=$this->db->get('contracts');

foreach($query->result() as $row){
      $contractnum .=''.$row->contract_no.'';
	 }

	return $contractnum; 
}


public function fetch_csrnum($clientnum,$cont_description){
$csrnum=null;
$this->db->select('csrno');
$this->db->where('description',$cont_description);
$this->db->where('clientno',$clientnum);
$query=$this->db->get('supply_requests');
$counter=$query->row();

if($counter !=null){
	foreach($query->result() as $row){
      $csrnum .=''.$row->csrno;
	 }
	}else{
		$csrnum='NO CSR';
	}

	return $csrnum; 
}


public function service_entry($callnumber,$serviceno,$servicedate,$fromtime,$totime,$equipmodel
	, $equipserial,$equipdescrip, $town,$location,$actiontaken,$servicestate ){
$data=array(
				'call_no'=>$callnumber,	'service_no'=>$callnumber.'-'.$serviceno,'service_date'=>$servicedate,
				'from2'=>$fromtime,'to2'=>$totime,
				'location'=>$location,'town'=>$town,'equip_descrip'=>$equipdescrip,'equip_model'=>$equipmodel,
				'serial'=>$equipserial,'action'=>$actiontaken,'status'=>$servicestate
				);
$this->db->insert('service',$data);

if($this->db->affected_rows()>0)
{
	$this->db->set('status',$servicestate);
	$this->db->where('call_no',$callnumber);
	$this->db->update('calls');

	$data=array(
		'claimno'=>'NA','call_no'=>$callnumber, 'service_no'=>$serviceno, 'km'=>0,'psvfare'=>0,
		'bfast'=>0, 'lunch'=>0,'dinner'=>0, 'accomod'=>0,'laundry'=>0,'petties'=>0,'others'=>0,
		'status'=>'NO CLAIM','date_claimed'=>'NA'
	);

	$this->db->insert('claims',$data);

	return true;
}
else{
	return false;
}

}

public function fetch_serviceentries(){
$staffno= $this->session->userdata('user_id');
$this->db->select('calls.call_no as callnumber,service.service_no as service_no,service.service_date as servicedate,service.from2 as from2,service.to2 as to2,clients.clientname as clientname,service.equip_model as equip_model,service.serial as serial, service.location as location,contracts.contract_no as contractno, service.town as town,calls.to_do as todo,service.action as action,service.status as status,staff.staffname as openby');
  $this->db->from('calls');
  $this->db->join('service','calls.call_no = service.call_no','left');
  $this->db->join('contracts','calls.contract_no=contracts.contract_no','left');
   $this->db->join('clients','contracts.client_no=clients.client_no','left');
    $this->db->join('staff','calls.technician=staff.staffno','left');
    $this->db->where('calls.technician ='.$staffno);
   $this->db->order_by('service.service_date','desc');
   $query=$this->db->get();

   if($query->num_rows()>0){
   	return $query->result();   	
   }
	
}

public function fetch_csrserviceentries(){
	$staffno= $this->session->userdata('user_id');
$this->db->select('calls.call_no as callnumber,service.service_no as service_no,service.service_date as servicedate,service.from2 as from2,service.to2 as to2,clients.clientname as clientname,service.equip_model as equip_model,service.serial as serial, service.location as location,supply_requests.csrno as contractno, service.town as town,calls.to_do as todo,service.action as action,service.status as status,staff.staffname as openby');
  $this->db->from('calls');
  $this->db->join('service','calls.call_no = service.call_no','left');
  $this->db->join('supply_requests','calls.contract_no=supply_requests.csrno','left');
   $this->db->join('clients','supply_requests.clientno=clients.client_no','left');
    $this->db->join('staff','calls.technician=staff.staffno','left');
    $this->db->where('calls.technician ='.$staffno);
   $this->db->order_by('service.service_date','desc');
   $query=$this->db->get();

   if($query->num_rows()>0){
   	return $query->result();   	
   }
}

}
