<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Mod_login extends CI_Model{

//private variables
	//private $user_ID; private $_name; private $_username; 
	//private $_email; private $_password; private $status;

   /* public function setUserID($userID){
    	$this->user_ID=$userID;
    }*/
  /*  public function setPassword($password){
 $this->_password=$password;

    }*/

/*	public function getUserInfo(){
 $this->db->select(array('u.user_ID','u.name','u.email'));
 $this->db->from('users as u');
 $this->db->where('u.user_ID',$this->$user_ID);
 $query=$this->db->get();
 return $query->row_array();
}
*/
public function verifyuser($email,$password){

$this->db->select('owner');
$this->db->from('webusers');
$this->db->where('email',$email);
$this->db->where('password',$password);
$query=$this->db->get();
 $user_id='';
 foreach($query->result() as $row){
$user_id .=''.$row->owner.'';
 }
return $user_id;
}


public function getuserdata($email){
	$this->db->select('email');
	$this->db->from('webusers');
	$this->db->where('email',$email);
	$query=$this->db->get();

 $usermail=''; 
foreach($query->result() as $row){
		$usermail .=''.$row->owner.'';
}
	return $usermail;
}

}