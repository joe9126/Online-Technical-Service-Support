<?php
class Modclaims extends CI_Model{

		public function fetch_serviceentries(){
	$staffnum=$this->session->userdata('user_id');
$this->db->select('calls.call_no as callnumber,service.service_no as service_no,service.service_date as servicedate,service.from2 as from2,service.to2 as to2,
clients.clientname as clientname,service.equip_model as equip_model,service.serial as serial, service.location as location,contracts.contract_no as contractno, service.town as town,calls.to_do as todo,service.action as action,service.status as status,staff.staffname as openby, claims.status as claimstate ');
  $this->db->from('calls');
  $this->db->join('service','calls.call_no = service.call_no','left');
  $this->db->join('contracts','calls.contract_no=contracts.contract_no','left');
   $this->db->join('clients','contracts.client_no=clients.client_no','left');
   $this->db->join('staff','calls.technician=staff.staffno','left');
    $this->db->join('claims','service.service_no=claims.service_no','left');
    $this->db->where('calls.technician',$staffnum);
   $this->db->order_by('service.service_date','desc');
   $query=$this->db->get();

   if($query->num_rows()>0){
   	return $query->result();   	
   }
	
}

public function createclaim($serviceno,$transporttype,$transport,$breakfasttype,$breakfast,
			$lunchtype,$lunch,$dinnertype,$dinner,$accomodtype,$accomodation,$laundry,$petties,$others){

$this->db->select('call_no');
$this->db->from('service');
$this->db->where('service_no',$serviceno);
$query=$this->db->get();
$callnumber='';
if($query->num_rows()>0){
	foreach($query->result() as $row){
		$callnumber .=''.$row->call_no;
	}
}
 
$claimno='TS2018'.'/'.(rand(10,100000)); $data='';
/*
$kmclaim=null; 
if($transporttype=='Private'){
	if($transport>40){
		$kmclaim=($40*20)+(($transport-40)*10);
	}else if($transport<=40){
		$kmclaim=$transport*20;
	}
} elseif($transporttype=='Public'){
	$kmclaim=0;
} elseif($transporttype=='Company Provided'){
	$kmclaim=0; $transport=0;
}
*/
$this->db->select('call_no');
$this->db->from('claims');
$this->db->where('service_no',$serviceno);
$query2=$this->db->get();

if($query2->num_rows()<1){
if($transporttype=='Private'){
	$data=array(
'claimno'=>'NA','call_no'=>$callnumber, 'service_no'=>$serviceno,'km'=>$transport, 'psvfare'=>0,'bfast'=>$breakfast,'lunch'=>$lunch, 'dinner'=>$dinner, 'accomod'=>$accomodation,'laundry'=>$laundry, 'petties'=>$petties, 'others'=>$others,'status'=>'UNCLAIMED','date_claimed'=>'NA'
);
$this->db->insert('claims',$data);
if($this->db->affected_rows()>0){
	return true;
}else{
	return false;
}

}
else if($transporttype=='Public'){
	$data=array(
'claimno'=>'NA','call_no'=>$callnumber, 'service_no'=>$serviceno,'km'=>0, 'psvfare'=>$transport,'bfast'=>$breakfast,'lunch'=>$lunch, 'dinner'=>$dinner, 'accomod'=>$accomodation,'laundry'=>$laundry, 'petties'=>$petties, 'others'=>$others,'status'=>'UNCLAIMED','date_claimed'=>'NA'
);

$this->db->insert('claims',$data);
if($this->db->affected_rows()>0){
	return true;
}else{
	return false;
}
}
elseif($transporttype=='Company Provided'){
		$data=array(
'claimno'=>'NA','call_no'=>$callnumber, 'service_no'=>$serviceno,'km'=>0, 'psvfare'=>0,'bfast'=>$breakfast,'lunch'=>$lunch, 'dinner'=>$dinner, 'accomod'=>$accomodation,'laundry'=>$laundry, 'petties'=>$petties, 'others'=>$others,'status'=>'UNCLAIMED','date_claimed'=>'NA'
);

$this->db->insert('claims',$data);
if($this->db->affected_rows()>0){
	return true;
}else{
	return false;
}

}

}

else{
if($transporttype=='Private'){
	$data=array(
'claimno'=>'NA','call_no'=>$callnumber, 'service_no'=>$serviceno,'km'=>$transport, 'psvfare'=>0,'bfast'=>$breakfast,'lunch'=>$lunch, 'dinner'=>$dinner, 'accomod'=>$accomodation,'laundry'=>$laundry, 'petties'=>$petties, 'others'=>$others,'status'=>'UNCLAIMED','date_claimed'=>'NA'
);
$this->db->update('claims',$data);
if($this->db->affected_rows()>0){
	return true;
}else{
	return false;
}

}
else if($transporttype=='Public'){
	$data=array(
'claimno'=>'NA','call_no'=>$callnumber, 'service_no'=>$serviceno,'km'=>0, 'psvfare'=>$transport,'bfast'=>$breakfast,'lunch'=>$lunch, 'dinner'=>$dinner, 'accomod'=>$accomodation,'laundry'=>$laundry, 'petties'=>$petties, 'others'=>$others,'status'=>'UNCLAIMED','date_claimed'=>'NA'
);

$this->db->update('claims',$data);
if($this->db->affected_rows()>0){
	return true;
}else{
	return false;
}
}
elseif($transporttype=='Company Provided'){
		$data=array(
'claimno'=>'NA','call_no'=>$callnumber, 'service_no'=>$serviceno,'km'=>0, 'psvfare'=>0,'bfast'=>$breakfast,'lunch'=>$lunch, 'dinner'=>$dinner, 'accomod'=>$accomodation,'laundry'=>$laundry, 'petties'=>$petties, 'others'=>$others,'status'=>'UNCLAIMED','date_claimed'=>'NA'
);

$this->db->update('claims',$data);
if($this->db->affected_rows()>0){
	return true;
}else{
	return false;
}

}

}

	
}

public function checkserviceno($serviceno){
	$this->db->select('service_no');
	$this->db->where('service_no',$serviceno);
	$query=$this->db->get('service');

	if($query !=null){
		return true;
	}else{
		return false;
	}
}
} 