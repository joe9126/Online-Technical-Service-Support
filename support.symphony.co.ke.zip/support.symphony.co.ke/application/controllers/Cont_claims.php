<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cont_claims extends CI_Controller{

public  function __construct(){
	parent:: __construct();
	$this->load->model('modclaims');


}
	public function claims(){

		 if($this->session->userdata('user_id') !=null){
		$this->load->view('header');
		
	$claimdata=$this->modclaims->fetch_serviceentries();
	$data['service_entries']='';

	if($claimdata!=null){
		$data['service_entries']=$claimdata;
		$this->load->view('claims',$data);
	}
	
		$this->load->view('footer');
	}
	else{
	redirect(base_url()."index.php/cont_home/login");
}

}

public function validateclaims(){

	$this->load->library('form_validation');
	$this->form_validation->set_rules('serviceno','service number','trim|required');
	$this->form_validation->set_rules('transport','transport ','trim|required');
	$this->form_validation->set_rules('breakfast','breakfast','trim|required');
	$this->form_validation->set_rules('lunch','lunch','trim|required');
	$this->form_validation->set_rules('dinner','dinner','trim|required');
	$this->form_validation->set_rules('accomodation','accomodation','trim|required');
	$this->form_validation->set_rules('laundry','laundry','trim|required');
	$this->form_validation->set_rules('petties','petties','trim|required');
	$this->form_validation->set_rules('others','others','trim|required');

	if($this->form_validation->run()){
		$serviceno=$this->input->post('serviceno');
		$transporttype=$this->input->post('transporttype');
		$transport=$this->input->post('transport');
		$breakfasttype=$this->input->post('breakfasttype');
		$breakfast=$this->input->post('breakfast');
		$lunchtype=$this->input->post('lunchtype');
		$lunch=$this->input->post('lunch');
		$dinnertype=$this->input->post('dinnertype');
		$dinner=$this->input->post('dinner');
		$accomodtype=$this->input->post('accomodtype');
		$accomodation=$this->input->post('accomodation');
		$laundry=$this->input->post('laundry');
		$petties=$this->input->post('petties');
		$others=$this->input->post('others');

		$servicenostate=$this->modclaims->checkserviceno($serviceno);
		if($servicenostate==TRUE){
			$results=$this->modclaims->createclaim($serviceno,$transporttype,$transport,$breakfasttype,$breakfast,
			$lunchtype,$lunch,$dinnertype,$dinner,$accomodtype,$accomodation,$laundry,$petties,$others);
		if($results==TRUE){
			$this->session->set_flashdata('claim_success_msg','Mileage claim created successfully!');
			$this->claims();
		}else{
			$this->session->set_flashdata('claim_error_msg','Mileage claim not created. Try again!');
			$this->claims();
		}	
	}else{
			//$this->session->set_flashdata('error_msg','Service number '.$serviceno.' does not exist!');
		$this->claims();
		}
		

	}else{
	$this->session->set_flashdata('error_msg','Claim not created!');
		$this->claims();
	}



} 

}
