<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cont_home extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct(){
    parent::__construct();
   
}
	
	public function index()
	{
if ($this->session->userdata('session_data')==FALSE){
	redirect('login');
}
else{
	 
redirect('dashboard');

}
		
	}

	public function login(){
		//$this->load->view('header');
		$this->load->view('login');
		$this->load->view('loginfooter');
	}

	public function validatelogin() {
		$this->load->library('form_validation');
		$this->form_validation->set_rules('email','Email','trim|required|valid_email');
		$this->form_validation->set_rules('password','Password','trim|required');

		if ($this->form_validation->run()===TRUE){
			$email=$this->input->post('email');
			$password=$this->input->post('password');
			
			//modal function 
			$this->load->model('mod_login');
			$userid=$this->mod_login->verifyuser($email,$password);
			//$username=$this->mod_login->getuserdata($email);
			
			if($userid !=null){
 		$session_data=array('email'=> $email,'password' =>$password, 'user_id'=>$userid);
			$this->session->set_userdata($session_data);
		 redirect(base_url().'index.php/Cont_home/dashboard');
			} 
			else{
	$this->session->set_flashdata('error','Invalid email or password!');
	redirect(base_url().'index.php/Cont_home/login');
				}
		
	}
	else{

		$this->login();
	}
	}


	public function dashboard(){

	if($this->session->userdata('user_id')!=null){
    $this->load->view('header');
    $this->load->view('dashboard');
    $this->load->view('footer');		

	}	else{
		redirect(base_url().'Cont_home/login');
	}

	}

	public function logout(){
	
        $this->session->unset_userdata('email');
        $this->session->unset_userdata('is_authenticated');
        $this->session->sess_destroy();
        
        redirect(base_url().'index.php/cont_home/login');
	}
}
