<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cont_calls extends CI_Controller
{
	
	 public function __construct()
	{
			
 parent:: __construct();
  // $login_status = $this->check_session();
/*if ($this->session->userdata('session_data')==FALSE){
	redirect('Cont_home/login');
} 
*/
$this->load->model('modcalls');
$this->load->library('form_validation');

			}


	public function opencall(){
   if($this->session->userdata('user_id') !=null){
   $client_query=$this->modcalls->getclients();
$client_data['clients']=null;
    	if($client_query==TRUE){
    $client_data['clients']=$client_query;
    	}else{
    		$client_data['clients']='no clients';
    	}

		$query=$this->modcalls->getcontractcalls();

		$contractcalldata['contractcallsdata']=null;
		if($query==TRUE){
			$contractcalldata['contractcallsdata']=$query;
		}
		
$query2=$this->modcalls->getcsrcalls();
$csrcalldata['csrcallsdata']=null;
		if($query2==TRUE){
			$csrcalldata['csrcallsdata']=$query2;
		}

$data=$csrcalldata+$contractcalldata+$client_data;
 //$this->load->view('profileinfo');
    $this->load->view('header');
 $this->load->view('opencall',$data);
 $this->load->view('footer');

	}
	else{
	redirect(base_url()."index.php/cont_home/login");
}
}

	public function validatecall(){
$this->load->library('form_validation');
$this->form_validation->set_rules('calldate','Call date','trim|required');
$this->form_validation->set_rules('callnumber','Call number','trim|required');
$this->form_validation->set_rules('openby','Open by','trim|required');
$this->form_validation->set_rules('client','Client ','trim|required');
$this->form_validation->set_rules('contractdescription','Contract description','trim|required');
$this->form_validation->set_rules('contractno','Contract number','trim|required');
$this->form_validation->set_rules('todo','To do','trim|required');

if($this->form_validation->run())
{
	$calldate=$this->input->post('calldate');
	$callnumber=$this->input->post('callnumber');
	$openby=$this->input->post('openby');
	//$client=$this->input->post('client');
	//$reference=$this->input->post('reference');
	//$contract=$this->input->post('contractdescription');
	$contractno=$this->input->post('contractno');
	$todo=$this->input->post('todo');

	 // LOAD MODEL TO CHECK IF CALL EXISTS
$callstatus=$this->modcalls->check_call($callnumber);

if($callstatus!=null){
$this->session->set_flashdata('error_msg','Call number '.$callnumber.' already exists! Try again with new call number!');
$this->opencall();
}
else{
$result=$this->modcalls->callopening($callnumber,$calldate,$openby,$contractno,$todo);

if($result==FALSE){
	$this->session->set_flashdata('error_msg','An error occured! Try again!');
}
else{
	$this->session->set_flashdata('success_msg','Call opened successfully!');
 			redirect(base_url().'index.php/Cont_calls/opencall');
}

}

}else{
	$this->session->set_flashdata('error_msg','An error occured! Try again!');
	redirect(base_url().'index.php/Cont_calls/opencall');
}

	}


	public function service_entry(){
$this->load->model('modcalls');
$results= $this->modcalls->fetch_serviceentries();
$csrresults=$this->modcalls->fetch_csrserviceentries();

$data1['service']=null;
$data2['csrservices']=null;

if($results ==TRUE){
	$data1['service']=$results;
}

if($csrresults==TRUE){
$data2['csrservices']=$csrresults;
}

$data=$data1+$data2;

	$this->load->view('header');
	$this->load->view('service_entry',$data);
	$this->load->view('footer');
		
	}

	public function validateservice(){

$this->form_validation->set_rules('callnumber','call number','trim|required');
$this->form_validation->set_rules('serviceno','service number','trim|required');
$this->form_validation->set_rules('servicedate','service date','trim|required');
$this->form_validation->set_rules('fromtime','from time ','trim|required');
$this->form_validation->set_rules('totime','to time','trim|required');
$this->form_validation->set_rules('equipmodel','equipment model','trim|required');
$this->form_validation->set_rules('equipserial','equipment serial','trim|required');
$this->form_validation->set_rules('equipdescrip','equipment description','trim|required');
$this->form_validation->set_rules('town','town','trim|required');
$this->form_validation->set_rules('location','location','trim|required');
$this->form_validation->set_rules('actiontaken','action taken','trim|required');
$this->form_validation->set_rules('servicestate','service satet','trim|required');

	if($this->form_validation->run()===TRUE){
	$callnumber=$this->input->post('callnumber');
	$serviceno=$this->input->post('serviceno');
	$servicedate=$this->input->post('servicedate');
	$fromtime=$this->input->post('fromtime');
	$totime=$this->input->post('totime');
	$equipmodel=$this->input->post('equipmodel');
	$equipserial=$this->input->post('equipserial');
	$equipdescrip=$this->input->post('equipdescrip');
	$town=$this->input->post('town');
	$location=$this->input->post('location');
	$actiontaken=$this->input->post('actiontaken');
	$servicestate=$this->input->post('servicestate');

	$results=$this->modcalls->service_entry($callnumber,$serviceno,$servicedate,$fromtime,$totime,$equipmodel
	, $equipserial,$equipdescrip, $town,$location,$actiontaken,$servicestate );

	if($results==TRUE){
    $this->session->set_flashdata('service_success_msg','Service details saved successfully');
    $this->service_entry();
	}else{
		$this->session->set_flashdata('service_error_msg','An error occured. Try again!');
		$this->service_entry();
	}
	}
else{
$this->service_entry();
}

	}

	  public function getcallnumber(){
        $this->load->model('modcalls');
        $keyword=$this->input->post('callnumber');
        $data=$this->modcalls->searchcall($keyword);        
        echo json_encode($data);
    }


     public function fetch_contdescription(){
     	$client_id=$this->input->post('client_id');
     	$reference=$this->input->post('reference');
	if($client_id!=null)
    	{
    		$results = $this->modcalls->fetch_contdescription($client_id,$reference);
    		echo $results;
    	}

    }

    public function fetch_contractnum(){
    	$cont_description=$this->input->post('cont_description');
    	$reference=$this->input->post('reference');
    	$clientnum=$this->input->post('client');
    	if($reference =='CSR')
    	{
    		$results=$this->modcalls->fetch_csrnum($clientnum,$cont_description);
    		echo $results;
    		
    	}
    	elseif($reference=='CONTRACT'){
    		$results= $this->modcalls->fetch_contractnum($clientnum,$cont_description);
    		echo $results;
    	}
    }



    
}