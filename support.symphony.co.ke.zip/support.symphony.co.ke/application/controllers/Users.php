<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 */
class Users extends CI_Controller
{
	

	function createuserprofile(){
		$this->load->view('header');
		$this->load->view('usersignup');
		$this->load->view('footer');
	}
}