<div class="container">
	
	<div class="row">
		<div class="col-lg-12">
			
<div class="col-lg-1"></div>
<div class="col-lg-10">
	
<div class="row">
	<div class="col-lg-4">
		<button type="button" class="btn btn-primary btn-block" style="border-radius: 24px;
		background-color: #161316;   border-color: #8064A2;
		text-align: center;padding: 50px 50px;display: inline-block;font-size: 40px;
  font-weight: normal;"><a href="<?php echo base_url();?>index.php/cont_calls/opencall" style="color:inherit">New Call</a></button>
	</div>

	<div class="col-lg-4">
		<button type="button" class="btn btn-primary btn-block" style="border-radius: 24px;
		text-align: center;padding: 50px 50px;display: inline-block;font-size: 40px;
  font-weight: normal; margin: 0;display: table-cell; background-color: #161316;   border-color: #8064A2;
    vertical-align: middle;"><a href="<?php echo base_url();?>index.php/cont_calls/service_entry" style="color:inherit">Service</a></button>
	</div>

	<div class="col-lg-4">
		<button type="button" class="btn btn-primary btn-block" style="border-radius: 24px;
		text-align:center;padding: 50px 50px;display: inline-block;font-size: 40px;background-color: #161316;   border-color: #8064A2; font-weight: normal;"> <a href="<?php echo base_url();?>index.php/cont_claims/claims" style="color:inherit"> Claim</a></button>
	</div>
</div>

<div class="row">
	<div class="col-lg-12">
		<br>
	</div>
</div>

<div class="row">
	<div class="col-lg-4"></div>
	 
		<div class="col-lg-4">
		<button type="button" class="btn btn-primary btn-block" style="border-radius: 24px;
		text-align:center;padding: 50px 50px;display: inline-block;font-size: 40px;
  font-weight: normal;"><a href="<?php echo base_url();?>index.php/cont_home/logout" style="color:inherit"> Logout</a></button>
	</div>

	 
	<div class="col-lg-4"></div>
</div>

</div>
<div class="col-lg-1"></div>

		</div>
	</div>
</div>