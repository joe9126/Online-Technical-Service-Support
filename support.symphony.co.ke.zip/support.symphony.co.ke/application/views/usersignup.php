<div class="container">
	
<div class="row">
	<div class="col-lg-12">
		
<h3 class="card-header info-color white-text text-center py-4" style="text-shadow: 2px 2px 5px white">
        <strong> User Profile Creation</strong>
    </h3>
<div class="form">
	
 		<div class="table">
	<table> 
		<thead>
			<ul class="nav nav-tabs">
  <li class="active"><a data-toggle="tab" href="#home">New User</a></li>
  <li><a data-toggle="tab" href="#menu1">Update Username</a></li>
  <li><a data-toggle="tab" href="#menu2">Update Password</a></li>
   <li><a data-toggle="tab" href="#menu2">Delete User</a></li>
</ul>

	</thead>
	<tbody>
	<div class="tab-content">
  <div id="home" class="tab-pane fade in active"style="background: #ffffff">
    
    <form >
    <div class="row" >

    	<div class="col-lg-1">
    	 <label for="">Usertype:</label>
    	</div>

    	<div class="col-lg-1">
       		<select class="form-control" name="usertype" id="usertype" type="select">
    		<option>Administrator</option>	
    		<option>User</option>
    		</select>
     	</div>

    	<div class="col-lg-1">
   	<label for="userid">User ID:</label>	
    	</div>

    	<div class="col-lg-1">
      <input  class="form-control" type="userid" name="userid">	 
    	</div>

    	<div class="col-lg-1"></div>
    	<div class="col-lg-1"></div>
    </div>
     </form>
  </div>

  <div id="menu1" class="tab-pane fade">
    <h3>Menu 1</h3>
    <p>Some content in menu 1.</p>
  </div>

  <div id="menu2" class="tab-pane fade">
    <h3>Menu 2</h3>
    <p>Some content in menu 2.</p>
  </div>
</div>		
			</tbody>
		</table>	

		</div>

	 
</div>

	</div>
</div>

</div>