<div class="container">

	<div class="row" id="mainrow">
	<!--<div class="col-lg-1"></div> -->
<div class="col-lg-12" style="box-shadow:0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19)">

<h3 class="card-header info-color white-text text-center py-4" style="text-shadow: 2px 2px 5px white">
        <strong>Service Entry</strong>
    </h3>
			
<div class="shadow-lg p-3 mb-5 bg-black rounded">

<span class="text-success" role="alert">	
<h3 style="text-align: center"><strong><?php echo $this->session->flashdata('service_success_msg');?></strong></h3>
</span>

<span class="text-danger" role="alert">	
<h3 style="text-align: center"><strong><?php echo $this->session->flashdata('service_error_msg');?></strong></h3>
</span>

<form  method="post" action="<?php echo base_url();?>index.php/cont_calls/validateservice">
		<!--<span class="alert alert-success"><strong>New Call Opened Successfully!</strong>  </span>-->
	
<div class="row" id="mainsubrow" style="background: #ccc7c9">					
<div class="col-lg-4" style="background: #ccc7c7">
		<legend><h5 style="text-color: #ffffff">Call Details</h5></legend>
			
			<div class="form-group">
			<label>Call No *</label>	
	<input class="form-control" id="callnumber" type="text" name="callnumber" placeholder="Search Call no."  >
			<ul class="dropdown-menu txtcountry" style="margin-left:15px;margin-right:0px;" role="menu" aria-labelledby="dropdownMenu"  id="DropdownCountry"></ul>
	<span class="text-danger"><?php echo form_error('callnumber');?></span>
			</div>	

           <div class=" form-group">
			<label>Technician:</label>	
			<input class="form-control" id="technician" type="text" name="technician" readonly="auto-generated" >
			</div>	

			<div class=" form-group">
				<label>Client:</label>
			<input class="form-control" type="text" name="client" id="client" readonly >
			<span class="text-danger"><?php echo form_error('client');?></span>
			</div>
			<div class=" form-group">
			<label>Fault Reported:</label>	
			<input class="form-control" id="fault" type="text" name="fault" readonly >

			</div>	

			<div class=" form-group">
			<label>Status:</label>	
			<input class="form-control" id="status" type="text" name="status" readonly>

			</div>
</div>

<div class="col-lg-4" style="background: #ffffff">
			<legend><h5 style="text-color: #ffffff">Service Details</h5></legend>

		
	<div class=" form-group">
		<div class="control">
			<p><label>Service No:</label>	
<input  class="form-control" type="text" name="serviceno" id="serviceno" value="<?php echo(rand(10,100000));?>" readonly >
  <span class="text-danger"><?php echo form_error('serviceno');?></span>
			</p>
		</div>
	</div>	
		<div class=" form-group">
			<div class="control">
			<p><label> Date *</label>	
			<input class="form-control" type="Date" name="servicedate" id="servicedate">
			
			</p>
			<span class="text-danger"><?php echo form_error('servicedate');?></span>
		</div>
		</div>	

<div class=" form-group">
			 <div class="control">
        <label for="fromtime">From *</label>
        <input type="time" class="form-control" id="fromtime" name="fromtime"   />
        <span class="text-danger"><?php echo form_error('fromtime');?></span>
           </div>          
			 <div class="control">
        <label for="fromtime">To *</label>
        <input type="time" class="form-control" id="totime" name="totime"  />
        <span class="text-danger"><?php echo form_error('totime');?></span>
           </div>          
	  </div>


			<div class=" form-group">
			<p><label>Equipment Model *</label>	
			<input class="form-control" type="text" name="equipmodel" id="equipmodel" placeholder="e.g HP G 450"  />
			<span class="text-danger"><?php echo form_error('equipmodel');?></span>
			</p>
			</div>

			<div class=" form-group">
			<p><label>Equipment Serial *</label>	
			<input class="form-control" type="text" name="equipserial" id="equipserial" placeholder="xxxxxxxxxxx"  />
			<span class="text-danger"><?php echo form_error('equipserial');?></span>
			</p>
			</div>

</div>
			
<div class="col-lg-4" style="background: #ffffff">
			<h5 style="text-color: #ffffff"> <br>    </h5>

		<div class=" form-group">
			<label for="equipdescrip">Equipment Description *</label>		
<div class="dropdown">
<input type="text" class="form-control" placeholder="Equipment Description" name="equipdescrip" id="equipdescrip" >
</div>
	<span class="text-danger"><?php echo form_error('equipdescrip');?></span>
			</div> 

		<div class=" form-group">
<label for="town">Town *</label>		
<div class="dropdown">
 <select class="form-control" name="town" id="town" type="select" >
 	<option value="Others">--Select Town--</option>
 	<option value="Nairobi">Nairobi</option>
 	<option value="Kisumu">Kisumu</option>
  	<option value="Mombasa">Mombasa</option>
 	<option value="Nakuru">Nakuru</option>
 	<option value="Others">Others</option>
 </select>

</div>
	<span class="text-danger"><?php echo form_error('town');?></span>
			</div> 

<div class="form-group">
	<label for="location">Location *</label>
	<input class="form-control" type="text" name="location" placeholder="Location" >
	<span class="text-danger"><?php echo form_error('location');?></span>
</div>
	
 <div class=" form-group">
			 	<label>Action Taken *</label>
			<textarea  class="form-control" rows="5" name="actiontaken" id="actiontaken" ></textarea>
			<span class="text-danger"><?php echo form_error('actiontaken');?></span>
</div>

<div class=" form-group">
	<label>Service status *</label>
<div class="dropdown">
 <select class="form-control" name="servicestate" id="servicestate" type="select" >
 	<option value="Closed">--Select Status--</option>
 	<option value="Closed">Closed</option>
 	<option value="To Continue">To Continue</option>
  	<option value="Awaiting Parts">Awaiting Parts</option>
 	<option value="No Access">No Access</option>
 	<option value="No Work">No Work</option>
 </select>
</div>

	</div>	

</div>

</div>

<div class="row" id="reports" style="background: #ffffff">
	
<div class="col-lg-6">
	<label for="findings">Service Findings</label>
	<textarea  class="form-control" rows="5" name="findings" id="findings" ></textarea>
	
</div>

	<div class="col-lg-6">
<label for="recommendation">Service Findings</label>
	<textarea  class="form-control" rows="5" name="recommendation" id="recommendation" ></textarea>		
	</div><br>
</div>

<div class="row" style="background: #ffffff">
	<div class="col-lg-12">
		<legend><h4>Note: Items with * must be filled.</h4></legend>
	</div>
</div>

<div class="row" style="background: #ffffff" >
	<div class="col-lg-4"></div>
		<div class="col-lg-4">
		<div class="form-group">
		<button type="submit" class="btn btn-primary">Save</button>
	</div>	

		</div>
			<div class="col-lg-4"></div>

</div>	

			</form>

	<span class="text-danger"><?php	 echo $this->session->flashdata('error_msg');?>	</span>
	<span class="text-success">	<?php echo $this->session->flashdata('success_msg');?>	</span>
	
	</div> <!--closes md black rounded -->

</div> <!--closes col-lg-12 -->
<!--<div class="col-lg-1"></div> -->


</div><!--closes mainsubrow --> 

<br><br>
<div class="row">
<div class="col-lg-12" style="box-shadow:0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19)" >
<legend><h3 class="card-header info-color white-text text-center py-4" style="text-shadow: 2px 2px 5px white">
        <strong>Service Entries</strong>
    </h3></legend>

	<div class="row" style="background: #ffffff; height: 300px !important;  overflow: scroll;" >
	 
	<table class="table table-striped table-bordered">
	<th>
	<tr>
		<!-- -->
		<td><strong>Call No</strong></td><td><strong>Service No</strong></td>
		<td><strong>Service Date</strong></td><td><strong>From</strong></td>
		<td><strong>To</strong></td><td><strong>Client</strong></td>
		<td><strong>Equip Model</strong></td><td><strong>Equip Serial</strong></td>
		<td><strong>Location</strong></td> <td><strong>Town</strong></td>
		<td><strong>Fault</strong></td><td><strong>Action</strong></td><td><strong>Status</strong></td>
		<td><strong>Tech</strong></td>
	</tr>	
	</th>
	<tbody>
		
<?php if(!empty($service)){
	$i=1; $date=''; $client_name='';
foreach($service as $row){
$date=date('d M,Y', strtotime($row->servicedate));
if(!empty($row->clientname))
{
 ?>
<tr>	

<td align="center"><?php echo $row->callnumber;?></td>
<td align="center"><?php echo $row->service_no;?></td>
<td align="center"><?php echo $date;?></td>
<td align="center"><?php echo $row->from2;?></td>
<td align="center"><?php echo $row->to2;?></td>
<td align="center"><?php echo $row->clientname;?></td>
<td align="center"><?php echo $row->equip_model;?></td>
<td align="center"><?php echo $row->serial;?></td>
<td align="center"><?php echo $row->location;?></td>
<td align="center"><?php echo $row->town;?></td>
<td align="center"><?php echo $row->todo;?></td>
<td align="center"><?php echo $row->action;?></td>
<td align="center"><?php echo $row->status;?></td>
<td align="center"><?php echo $row->openby;?></td>
</tr>
<?php $i++;
}
elseif(empty($row->clientname)){

	foreach($csrservices as $rows){
$date=date('d M,Y', strtotime($rows->servicedate));
    if(!empty($rows->clientname)){ ?>
<tr>	

<td align="center"><?php echo $rows->callnumber;?></td>
<td align="center"><?php echo $rows->service_no;?></td>
<td align="center"><?php echo $date;?></td>
<td align="center"><?php echo $rows->from2;?></td>
<td align="center"><?php echo $rows->to2;?></td>
<td align="center"><?php echo $rows->clientname;?></td>
<td align="center"><?php echo $rows->equip_model;?></td>
<td align="center"><?php echo $rows->serial;?></td>
<td align="center"><?php echo $rows->location;?></td>
<td align="center"><?php echo $rows->town;?></td>
<td align="center"><?php echo $rows->todo;?></td>
<td align="center"><?php echo $rows->action;?></td>
<td align="center"><?php echo $rows->status;?></td>
<td align="center"><?php echo $rows->openby;?></td>
</tr>

   <?php }

	  }
   }
 }

}?>		

	</tbody>
</table>	

	</div>	


</div>
	
</div>
</div> <!--closes container -->