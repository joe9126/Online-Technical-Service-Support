

	<div id="container">

	<div class="row">
<div class="col-lg-1"></div>
<div class="col-lg-10" style="box-shadow:0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19)">

<h3 class="card-header info-color white-text text-center py-4" style="text-shadow: 2px 2px 5px white">
        <strong>New Call </strong>
    </h3>
<span class="text-success" role="alert">	
<h3 style="text-align: center"><strong><?php echo $this->session->flashdata('success_msg');?></strong></h3>
</span>

<span class="text-danger" role="alert">
<h3 style="text-align: center"><strong><?php echo $this->session->flashdata('error_msg');?></strong></h3>	</span>

<div class="shadow-lg p-3 mb-5 bg-black rounded">
	<legend><h5 style="text-color: #ffffff">Call Details</h5></legend>	

	<form method="post" action="<?php echo base_url();?>index.php/cont_calls/validatecall">

<div class="row" style="background: #ffffff">			
<div class="col-lg-4" >	

			<div class=" form-group">
				<label>Call Date:</label>
			<input class="form-control" type="Date" name="calldate" id="calldate" placeholder="Call Date" required>
			<span class="text-danger"><?php echo form_error('calldate');?></span>
			</div>

			<div class=" form-group">
			<label>Call No*</label>	
			<script type="text/javascript">
		    </script>
			<input class="form-control" id="callnumber" type="text" name="callnumber" 
			value="<?php echo date("Y");?>/<?php echo rand(10,10000);?>" readonly required >
				<span class="text-danger"><?php echo form_error('callnumber');?></span>
			</div>	
	
	<div class=" form-group">
			<p><label>Technician *</label>	
			<input class="form-control" type="text" name="openby" id="openby" placeholder="e.g John Doe" required="" value="<?php echo $this->session->userdata('email');?>" readonly>
			<span class="text-danger"><?php echo form_error('openby');?></span>
			</p>
	</div>	

<div class=" form-group">
			<label for="client">Client *</label>	
			<div class="dropdown">
 <select class="form-control" name="client" id="client" type="select" required >
 	<?php foreach($clients as $row){
 	echo '<option value="'.$row->client_no.'">'. $row->clientname.'</option>';
 	  }?>
 </select>
       </div>
</div>	

</div>

<div class="col-lg-4">

<div class="form-group">
	<p><label for="Reference">Reference*</label>
<select class="form-control" id="reference" name="reference" required>
	<option>--Select Reference--</option>
		<option value="CSR">CSR</option>
		<option value="CONTRACT">CONTRACT</option>

</select>

	</p>
</div>


<div class="form-group">
	<p>
		<label for="contractdescription">Ref. Description</label>
		<select class="form-control" type="select" id="contractdescription" name="contractdescription" required="">
	<option>--Select Description--</option>		
		</select>
	</p>
</div>


<div class=" form-group">
			<p><label>Contract No *</label>	
			<input class="form-control" type="text" name="contractno" id="contractno" placeholder="Contract number"  required="" readonly="" >
			<span class="text-danger"><?php echo form_error('contractno');?></span>
			</p>
</div>


<div class=" form-group">
			<label>To Do *</label>		
			<input class="form-control" type="text" name="todo" id="todo" placeholder="e.g Preventive maintenance" required=""><span class="text-danger"><?php echo form_error('todo');?></span>
			</div>
</div>

<div class="col-lg-4">
<br><br>
	<div class=" form-group" style="align-content: right;">
<button type="submit" class="btn btn-primary">Open Call</button>
			</div>
</div>

	</div>
</form>

<div class="row" style="background: #ffffff"><h5 style="text-align: center">
	<strong>Note: Items with * are required.</strong>
</h5></div>
	
	</div> <!--closes md black rounded -->



<div class="row" >
	<legend><h5 style="text-color: #ffffff">Service Calls</h5></legend>
<div class="col-lg-12" style="background: #ffffff; height: 300px !important;  overflow: scroll;" >
	

	<table class="table table-striped table-bordered" >
			<thead>
			
			<th class="hidden-xs"><strong>Call No</strong></th>
			<th><strong>Open Date</strong></th>
			<th><strong>Technician</strong></th>
			<th><strong>Client</strong></th>
			<th><strong>Activity</strong></th>
			<th><strong>Status</strong></th>
		    </thead>
			<tbody>
			<?php 
			if($contractcallsdata !=null){
			$i=1; $client_name='';

			foreach($contractcallsdata as $calls1){
				$date=date('d M,Y', strtotime($calls1->calldate));
				$client_name=$calls1->clientname;

				if(!empty($client_name)){
				?>	
				<tr>
				
			<td align="center"><?php echo $calls1->callno;?></td>
			<td align="left"><?php echo $date;?></td>
			<td align="left"><?php echo $calls1->technician;?></td>
			<td align="left"><?php echo $calls1->clientname;?></td>
			<td align="left"><?php echo $calls1->todo;?></td>
			<td align="left"><?php echo $calls1->status;?></td>
				</tr>
		<?php 
		 $i++; }

		  elseif (empty($clientname)) { ?>

		  	<?php foreach($csrcallsdata as $rows){?>
		  	<?php if(!empty($rows->clientname)){  ?>
		  	<tr>
				
			<td align="center"><?php echo $rows->callno;?></td>
			<td align="left"><?php echo $date;?></td>
			<td align="left"><?php echo $rows->technician;?></td>
			<td align="left"><?php echo $rows->clientname;?></td>
			<td align="left"><?php echo $rows->todo;?></td>
			<td align="left"><?php echo $rows->status;?></td>
				</tr>

		  	   <?php }?>	
			
		  <?php	}?>
		 
		<?php } ?>
		<?php }
	}?>
		</tbody>
	 </table>
	</div>

</div>

</div>	
<div class="col-lg-1"></div>
</div>
<!--
<div class="row">
<div class="panel-footer">
	<div class="row">
		<div class="col-lg-4">Page 1 of 5</div>
		<div class="col-lg-8">
			<ul class="pagination hidden-xs pull-right">
				<li><a href="#">1</a></li>
				<li><a href="#">2</a></li>
				<li><a href="#">3</a></li>
				<li><a href="#">4</a></li>
				<li><a href="#">5</a></li>
			</ul>
			<ul class="pagination visible-xs pull-right">
				<li><a href="#"><<</a></li>
				<li><a href="#">>></a></li>
			</ul>
		</div>
		<dir class="col-lg-4"></dir>
	</div>
</div>
</div>
-->

</div> <!-- this closes main div from the header.php-->

  <script>

   $(document).ready(function(){

$(document).on('change','#reference',function(){
var reference=$('#reference').val();
var client_id=$('#client').val();
   
  if(reference !='')
 	{
   		$.ajax({
   			url: "<?php echo base_url();?>index.php/cont_calls/fetch_contdescription",
   			method: "POST",
   			data: {client_id:client_id, reference:reference},
   			success: function(data){
   				$('#contractdescription').html(data);
   			}
   		})
 	}
   	});

   });
  </script>



  <script type="text/javascript">
  	$(document).ready(function(){

$(document).on('change','#contractdescription', function(){
	var cont_description=$('#contractdescription').val();
	var reference=$('#reference').val();
	var client=$('#client').val();

	if(cont_description !=''){
		$.ajax({
			url:"<?php echo base_url();?>index.php/cont_calls/fetch_contractnum",
			method: "POST",
			data: {cont_description:cont_description, reference:reference,client:client},
			success:function(data){
			$('#contractno').val(data);
				//document.getElementById('contractno').value=data ; 
			}
		})
	}
});
  	});


  </script>