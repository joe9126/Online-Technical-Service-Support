		
<div class="row" style="box-shadow: 5px 6px ">
	<div style="width: 500px; margin: 50px;">
		<h4> Service Calls</h4>
		<table class="table table-striped table-bordered">
			<tr><td><strong>No</strong></td><td><strong>Call No</strong></td><td><strong>Open Date</strong></td>
			<td><strong>Opened By</strong></td><td><strong>Equipment</strong></td><td><strong>Serial No</strong>
			</td><td><strong>Problem</strong></td><td><strong>Description</strong></td><td><strong>Status</strong></td>	</tr>
			
			<?php foreach($CALLS as $calls){?>	
				<tr>
			<td><?=$calls->CALLNUMBER;?></td><td><?=$calls->CALLDATE;?></td><td><?=$calls->OPENBY;?></td>
			<td><?=$calls->EQUIPMODEL;?></td><td><?=$calls->EQUIPSERIAL;?></td><td><?=$calls->PROBLEMREPORTED;?></td>
			<td><?=$calls->DESCRIPTION;?></td><td><?=$calls->STATUS;?></td>
				</tr>
		<?php }?>
		</table>
	</div>


</div>