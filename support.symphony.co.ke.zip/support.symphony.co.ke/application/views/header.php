<!DOCTYPE html>
<html>
<head>
	<title>Symphony Service Request</title>

 <!-- Latest compiled and minified JavaScript -->
   
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> 
        <!-- Latest compiled and minified JavaScript -->
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css">

        <!-- Latest compiled and minified CSS -->

<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>bootstrap/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<!--<script type="text/javascript" src="<?php //echo base_url();?>bootstrap/js/bootstrap.js" ></script> -->

<script type="text/javascript" src="<?php echo base_url();?>bootstrap/js/menubarscript.js" ></script>
<script src="<?php echo base_url(); ?>bootstrap/js/searchcallno.js"></script>
<<!--<script type="text/javascript" src="<?php //echo base_url();?>bootstrap/js/contractpicker.js" ></script> -->
<script type="text/javascript" src="<?php echo base_url();?>bootstrap/js/bootstrap.min.js" ></script>

<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>bootstrap/css/loginstyle.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>bootstrap/css/tablestyle.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>bootstrap/css/navbarstyle.css" rel="stylesheet" id="bootstrap-css">



<!------ Include the above in your HEAD tag ---------->

</head>

<body id="LoginForm">

 <div class="fixed-top" style="box-shadow:0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19)" >
<div class="row" >
  <div class="col-lg-2"></div>
  <div class="col-lg-8">
    <legend><h1 style=" text-align: center; color: #ffffff;">Symphony Service Support</h1></legend>
  </div>
   <div class="col-lg-2">
    <div class="row">
      <div class="col-lg-7">
         <input class="form-control input-sm" type="text" placeholder="" name="fullname" 
     value="<?php  $array=$this->session->userdata('email'); echo ''.$array;?>" id="fullname" readonly >
      </div>
       <div class="col-lg-5">
        <form action="<?php echo base_url();?>index.php/cont_home/logout">
           <button class="btn btn-primary"> Log Out</button>
        </form>
         
       </div>
    </div>     
     
        </div>
 
</div>
</div>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="<?php echo base_url();?>index.php/cont_home/dashboard">Dashboard</a>
  <a href="<?php echo base_url();?>index.php/cont_calls/opencall">New Call</a>
  <a href="<?php echo base_url();?>index.php/cont_calls/service_entry">Service Entry</a>
  <a href="<?php echo base_url();?>index.php/cont_claims/claims">Claims</a>
  <a href="#">Reports</a>
  <a href="<?php echo base_url();?>index.php/users/createuserprofile">Users</a>
   <a href="<?php echo base_url();?>index.php/cont_home/logout">Log Out</a>
</div>

<div id="main">

 
<br>
  <p><br><br> </p>
  <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; Menu</span>


<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
    document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
    document.body.style.backgroundColor = "white";
}
</script>
