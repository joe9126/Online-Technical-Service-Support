<div class="container">
	
<div class="row">
	<div class="col-lg-12" style="box-shadow:0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19)">
		<h3 class="card-header info-color white-text text-center py-4" style="text-shadow: 2px 2px 5px white">
        <strong> Claim Creation</strong>
    </h3>
<span class="text-success" role="alert">	
<h3 style="text-align: center"><strong><?php echo $this->session->flashdata('claim_success_msg');?></strong></h3>
</span>

<span class="text-danger" role="alert">	
<h3 style="text-align: center"><strong><?php echo $this->session->flashdata('claim_error_msg');?></strong></h3>
</span>

<form method="post" action="<?php echo base_url();?>index.php/cont_claims/validateclaims" >
    <div class="row" style="background: #ffffff;">
    	<div class="col-lg-4">

    		<div class="form-group">
    			<label  for="serviceno">Service Number *</label>
    		<input class="form-control" type="text" name="serviceno" placeholder="Service Number" >
    		<span class="text-danger"><?php echo form_error('serviceno');?></span>
    		</div>

    		<div class="form-group">
    			<label for="transporttype">Transport *</label>
    		<select class="form-control" name="transporttype" id="transporttype" type="select">
    				<option value="None">--Select Transport Type--</option>
    				<option value="Company Provided">Company Provided</option>
    				<option value="Private">Private</option>
    				<option value="Public">Public</option>
    			</select>
    		</div>

    		<div class="form-group">
    			<label for="transportclaim">Transport Claim * (enter km if private, leave blank if company provided)</label>
    		<input class="form-control input-sm" type="text" id="transport" name="transport" value="0.00" placeholder="Transport (Fare/KM)" >
    		<span class="text-danger"><?php echo form_error('transport');?></span>
    		</div>
    		
    		<div class="form-group">
    			<label for="breakfasttype">Breakfast *</label>
    			<select class="form-control" name="breakfasttype" id="breakfasttype" type="select">
    				<option value="None">--Select Receipt Status--</option>
    				<option value="receipted">Receipt</option>
    				<option value="no_receipt">No Receipt</option>
    			</select>

    		</div>
    		<div class="form-group">
    			<input class="form-control input-sm" id="breakfast" type="text" name="breakfast" value="0.00" placeholder="Breakfast amount" >
    			<span class="text-danger"><?php echo form_error('breakfast');?></span>
    		</div>
    	</div>

    	<div class="col-lg-4">
    		<div class="form-group">
    			<label for="lunch">Lunch *</label>
    			<select class="form-control" type="select" name="lunchtype" id="lunchtype">
    				<option value="None">--Select Receipt Status--</option>
    				<option value="receipted">Receipt</option>
    				<option value="no_receipt">No Receipt</option>
    			</select>
    			</div>

    		<div class="form-group">
    		<input class="form-control input-sm" type="text" id="lunch" name="lunch" value="0.00" placeholder="Lunch Amount" >
    		<span class="text-danger"><?php echo form_error('lunch');?></span>
    		</div>


    		<div class="form-group">
    			<label for="dinner">Dinner *</label>
    			<select class="form-control" type="select" name="dinnertype" id="dinnertype">
    				<option value="None">--Select Receipt Status--</option>
    				<option value="receipted">Receipt</option>
    				<option value="no_receipt">No Receipt</option>
    			</select>
    			</div>

    			<div class="form-group">
    		<input class="form-control input-sm" type="text" name="dinner" value="0.00" placeholder="Dinner Amount" >
    		<span class="text-danger"><?php echo form_error('dinner');?></span>
    		</div>

    		<div class="form-group">
    			<label for="dinner">Accomodation *</label>
    			<select class="form-control" type="select" name="accomodtype" id="accomodtype">
    				<option value="None">--Select Receipt Status--</option>
    				<option value="receipted">Receipt</option>
    				<option value="no_receipt">No Receipt</option>
    			</select>
    			</div>

    		<div class="form-group">
    		<input class="form-control input-sm" type="text" id="accomodation" name="accomodation" value="0.00" placeholder="Accomodation Amount" >
    		<span class="text-danger"><?php echo form_error('accomodation');?></span>
    		</div>

    	</div>


    	<div class="col-lg-4">
    		<div class="form-group">
    	<label for="laundry">Laundry *</label>
    	<input class="form-control input-sm" type="text" id="laundry" name="laundry" value="0.00" placeholder="Laundry Amount" >
    	<span class="text-danger"><?php echo form_error('laundry');?></span>
    		</div>

    		<div class="form-group">
    	<label for="petties">Petties *</label>
    	<input class="form-control input-sm" type="text" id="petties" name="petties" value="0.00" placeholder="Petties Amount" >
    	<span class="text-danger"><?php echo form_error('petties');?></span>
    		</div>


        <div class="form-group">
    	<label for="others">Others *</label>
    	<input class="form-control input-sm" type="text" id="others" name="others" value="0.00" placeholder="Other Expenses" >
    	<span class="text-danger"><?php echo form_error('others');?></span>
    		</div>
       <br><br>
		<div class="form-group">
			<button type="submit" class="btn btn-primary">Create</button>
		</div>
    	</div>

  </div>

</form>


	</div>
</div>


<><br><br>
<div class="row">
<div class="col-lg-12" style="box-shadow:0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19)" >
<legend><h3 class="card-header info-color white-text text-center py-4" style="text-shadow: 2px 2px 5px white">
        <strong>Service Claims</strong>
    </h3></legend>

	<div class="row" style="background: #ffffff; height: 300px !important;  overflow: scroll;" >
	 
	<table class="table table-striped table-bordered">
	<th>
	<tr>
		<!-- -->
		<td><strong>Call No</strong></td><td><strong>Service No</strong></td>
		<td><strong>Service Date</strong></td><td><strong>From</strong></td>
		<td><strong>To</strong></td><td><strong>Client</strong></td>
		<td><strong>Equip Model</strong></td><td><strong>Equip Serial</strong></td>
		<td><strong>Location</strong></td> <td><strong>Town</strong></td>
		<td><strong>Fault</strong></td><td><strong>Action</strong></td><td><strong>Status</strong></td>
		<td><strong>Tech</strong></td>
		<td><strong>Claim Status</strong></td>
	</tr>	
	</th>
	<tbody>
		
<?php if(!empty($service_entries)){
foreach($service_entries as $row){
$date= date('d M,Y',strtotime($row->servicedate))
 ?>
<tr>	
<td align="center"><?php echo $row->callnumber;?></td>
<td align="center"><?php echo $row->service_no;?></td>
<td align="center"><?php echo $date;?></td>
<td align="center"><?php echo $row->from2;?></td>
<td align="center"><?php echo $row->to2;?></td>
<td align="center"><?php echo $row->clientname;?></td>
<td align="center"><?php echo $row->equip_model;?></td>
<td align="center"><?php echo $row->serial;?></td>
<td align="center"><?php echo $row->location;?></td>
<td align="center"><?php echo $row->town;?></td>
<td align="center"><?php echo $row->todo;?></td>
<td align="center"><?php echo $row->action;?></td>
<td align="center"><?php echo $row->status;?></td>
<td align="center"><?php echo $row->openby;?></td>
<td align="center"><?php echo $row->claimstate;?></td>
</tr>
<?php }?>

<?php }?>		

	</tbody>
</table>	

	</div>	


</div>
	
</div>


</div>