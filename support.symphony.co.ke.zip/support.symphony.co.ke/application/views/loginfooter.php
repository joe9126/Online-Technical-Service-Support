
<br><br><br>
</body>


<!-- Footer -->
<footer id="LoginForm" class="page-footer font-small blue pt-4" style=" position: fixed; left: 0;bottom: 0;width: 100%; background-color: #424344;color: white;text-align: center;background-image:url('https://hdwallsource.com/img/2014/9/blur-26347-27038-hd-wallpapers.jpg');">

    <!-- Footer Links -->
    <div class="container-fluid text-center text-md-left">

      <!-- Grid row -->
      <div class="row">

        <!-- Grid column -->
        <div class="col-md-6 mt-md-0 mt-3">

          <!-- Content -->
          <!--  <h5 class="text-uppercase">Footer Content</h5>
          <p>Here you can use rows and columns here to organize your footer content.</p>
			-->
        </div>
        <!-- Grid column -->

        <hr class="clearfix w-100 d-md-none pb-3">

        <!-- Grid column -->
        
        <div class="col-md-3 mb-md-0 mb-3">

            <!-- Links -->
            <!--
            <h5 class="text-uppercase">Links</h5>

            <ul class="list-unstyled">
              <li>
                <a href="#!">Link 1</a>
              </li>
              <li>
                <a href="#!">Link 2</a>
              </li>
              <li>
                <a href="#!">Link 3</a>
              </li>
              <li>
                <a href="#!">Link 4</a>
              </li>
            </ul>

          </div>
      -->
          <!-- Grid column -->

          <!-- Grid column -->
         
          <!-- Grid column -->

      </div>
      <!-- Grid row -->

    </div>
    <!-- Footer Links -->

    <!-- Copyright -->
    <div class="footer-copyright text-center py-3">
      <a href="https://linkedin.com/in/joash-asewe-2b627886"> </a>
    </div>
    <!-- Copyright -->

  </footer>
  <!-- Footer -->

</html>