<!DOCTYPE html>
<html>
<head>
    <title>Symphony Service Request</title>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>

<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>bootstrap/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script type="text/javascript" src="<?php echo base_url();?>bootstrap/js/bootstrap.js" ></script>
<script type="text/javascript" src="<?php echo base_url();?>bootstrap/js/bootstrap.min.js" ></script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>bootstrap/css/loginstyle.css">
<!------ Include the above in your HEAD tag ---------->


</head> 

<body id="LoginForm">
<div class="container">
     
<h1 class="form-heading">login </h1>
<div class="login-form">
<div class="main-div">


    <div class="panel">
   
   <p>Please enter your email and password</p>
   </div>

<form id="Login" method="post" action="<?php echo base_url();?>index.php/cont_home/validatelogin" >

        <div class="form-group">
 <input type="email" class="form-control" id="email" name="email" placeholder="Email">
 <span class="text-danger"><?php echo form_error('email');?></span>
 </div>

        <div class="form-group">
            <input type="password" class="form-control" id="password" name="password" placeholder="Password" >
            <span class="text-danger"><?php echo form_error('password');?></span>
        </div>
        <div class="forgot">
        <a href="reset.html">Forgot password?</a>
</div>
        <button type="submit" class="btn btn-primary">Login</button>
      <span class="text-danger"><?php echo $this->session->flashdata("error");?></span>
    </form >
  
    </div>
</div>
</div>