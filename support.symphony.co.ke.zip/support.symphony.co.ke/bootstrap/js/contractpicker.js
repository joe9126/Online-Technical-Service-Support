

   $(document).ready(function(){

$(document).on('change','#reference',function(){
var reference=$('#reference').val();
var client_id=$('#client').val();
   
  if(reference !='')
 	{
   		$.ajax({
   			url: "<?php echo base_url();?>index.php/cont_calls/fetch_contdescription",
   			method: "POST",
   			data: {client_id:client_id, reference:reference},
   			success: function(data){
   				$('#contractdescription').html(data);
   			}
   		})
 	}
   	});

   });
 




  	$(document).ready(function(){

$(document).on('change','#contractdescription', function(){
	var cont_description=$('#contractdescription').val();
	if(cont_description !=''){
		$.ajax({
			url:"<?php echo base_url();?>index.php/cont_calls/fetch_contractnum",
			method: "POST",
			data: {cont_description:cont_description},
			success:function(data){
			$('#contractno').val(data);
				//document.getElementById('contractno').value=data ; 
			}
		})
	}
});
  	});


