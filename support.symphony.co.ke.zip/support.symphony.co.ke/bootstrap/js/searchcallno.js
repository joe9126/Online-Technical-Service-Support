$(document).ready(function () {
    $("#callnumber").keyup(function () {
        $.ajax({
            type: "POST",
            url: "http://localhost/support.symphony.co.ke/index.php/cont_calls/getcallnumber",
            data: {
                keyword: $("#callnumber").val()
            },
            dataType: "json",
            success: function (data) {
                if (data.length > 0) {
                    $('#DropdownCountry').empty();
                    $('#callnumber').attr("data-toggle", "dropdown");
                    $('#DropdownCountry').dropdown('toggle');
                }
                else if (data.length == 0) {
                    $('#callnumber').attr("data-toggle", "");
                }
                $.each(data, function (key,value) {
                    if (data.length >= 0)
                        $('#DropdownCountry').append('<li role="displayCountries" ><a role="menuitem dropdownCountryli" class="dropdownlivalue">' + value['callnumber'] + '</a></li>');
                });
            }
        });
    });
    $('ul.txtcountry').on('click', 'li a', function () {
        $('#callnumber').val($(this).text());
    });
});